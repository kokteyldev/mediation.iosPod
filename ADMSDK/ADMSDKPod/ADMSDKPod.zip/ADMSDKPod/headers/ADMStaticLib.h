//
//  ADMStaticLib.h
//  ADMStaticLib
//
//  Created by Bora-Mac on 13/04/16.
//  Copyright © 2016 kokteyl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ADMStaticLib : NSObject

@end
